from django.contrib import admin
from .models import Aricles

admin.site.register(Aricles)